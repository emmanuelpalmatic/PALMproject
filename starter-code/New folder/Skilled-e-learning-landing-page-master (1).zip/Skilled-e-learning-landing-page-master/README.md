# Skilled-e-learning-landing-page

## Table of Contents

- [Overview](#overview)
- [Screenshot](#screenshot)
- [Built with](#-built-with)
- [Author](#author)

## Overview

This is a solution to the [Skilled e-learning landing page challenge on Frontend Mentor](https://www.frontendmentor.io/challenges/skilled-elearning-landing-page-S1ObDrZ8q). The purpose of this challenge is to improve my coding skills by building realistic projects.

## Screenshot

![Skilled e-learning landing page](https://github.com/Bayoumi-dev/Skilled-e-learning-landing-page/blob/master/assets/skilled-preview.jpg)


## ⚙ Built with

- HTML
- CSS
- Mobile-first workflow

## Author
- Website - [bayoumi.dev](https://bayoumi.dev)
- Frontend Mentor - @Bayoumi-dev






